module.exports=[37483,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_expense-categories_route_actions_cc1e9674.js.map