module.exports=[95660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bongkaran_%5Bid%5D_route_actions_00c12b00.js.map