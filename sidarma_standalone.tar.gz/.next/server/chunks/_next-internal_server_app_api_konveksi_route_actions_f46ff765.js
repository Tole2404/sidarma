module.exports=[78444,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_konveksi_route_actions_f46ff765.js.map