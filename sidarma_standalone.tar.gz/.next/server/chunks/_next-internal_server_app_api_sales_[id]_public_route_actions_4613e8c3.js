module.exports=[64389,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_%5Bid%5D_public_route_actions_4613e8c3.js.map