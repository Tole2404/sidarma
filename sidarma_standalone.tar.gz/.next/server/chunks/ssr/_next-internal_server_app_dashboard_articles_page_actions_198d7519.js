module.exports=[37656,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_articles_page_actions_198d7519.js.map