module.exports=[33196,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_konveksi_page_actions_31c4b921.js.map