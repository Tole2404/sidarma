module.exports=[67636,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_seo_page_actions_e01db2d9.js.map