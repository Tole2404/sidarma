module.exports=[60988,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_kalkulator_page_actions_d96267fd.js.map