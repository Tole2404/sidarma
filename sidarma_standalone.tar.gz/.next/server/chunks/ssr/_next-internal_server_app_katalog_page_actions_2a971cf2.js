module.exports=[37457,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_katalog_page_actions_2a971cf2.js.map