module.exports=[11843,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_artikel_page_actions_0a758487.js.map