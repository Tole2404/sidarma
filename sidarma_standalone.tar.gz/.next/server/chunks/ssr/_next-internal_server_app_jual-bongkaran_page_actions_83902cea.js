module.exports=[61896,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_jual-bongkaran_page_actions_83902cea.js.map