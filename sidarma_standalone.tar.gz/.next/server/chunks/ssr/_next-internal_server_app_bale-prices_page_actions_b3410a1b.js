module.exports=[44796,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bale-prices_page_actions_b3410a1b.js.map