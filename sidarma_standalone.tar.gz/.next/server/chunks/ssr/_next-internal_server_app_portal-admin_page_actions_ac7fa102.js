module.exports=[96394,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal-admin_page_actions_ac7fa102.js.map