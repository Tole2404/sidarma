module.exports=[78880,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_produk_%5Bslug%5D_page_actions_0ff6fd32.js.map