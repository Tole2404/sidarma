module.exports=[96466,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_footer_page_actions_e2ab9100.js.map