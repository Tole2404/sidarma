module.exports=[69961,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bongkaran_%5Bid%5D_page_actions_438ae360.js.map