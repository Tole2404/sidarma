module.exports=[48733,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_landing_page_actions_0553ae0f.js.map