module.exports=[4695,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_theme_page_actions_1b3eae88.js.map