module.exports=[65602,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bongkaran_page_actions_feb8abae.js.map