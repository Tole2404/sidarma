module.exports=[52754,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bongkaran_route_actions_87bfe29e.js.map