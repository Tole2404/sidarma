module.exports=[89214,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_seo_route_actions_b78dbeec.js.map