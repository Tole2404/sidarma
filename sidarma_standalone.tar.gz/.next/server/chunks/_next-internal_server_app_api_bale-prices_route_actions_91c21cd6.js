module.exports=[83642,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bale-prices_route_actions_91c21cd6.js.map