module.exports=[38384,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_landing_route_actions_6e7c685a.js.map