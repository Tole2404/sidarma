module.exports=[20365,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bale-prices_%5Bid%5D_route_actions_b3ce52fc.js.map