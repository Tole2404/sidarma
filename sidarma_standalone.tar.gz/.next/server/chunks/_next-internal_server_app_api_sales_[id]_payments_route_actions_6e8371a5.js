module.exports=[97651,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sales_%5Bid%5D_payments_route_actions_6e8371a5.js.map