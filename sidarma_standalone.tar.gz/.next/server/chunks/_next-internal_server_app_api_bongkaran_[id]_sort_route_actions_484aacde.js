module.exports=[2837,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bongkaran_%5Bid%5D_sort_route_actions_484aacde.js.map