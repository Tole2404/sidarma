module.exports=[79132,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_bongkaran_%5Bid%5D_sort_%5BbatchId%5D_route_actions_c11330b9.js.map