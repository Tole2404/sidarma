globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2bf3d2557f5eae5a.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/396f90e8b7ccb31f.js",
    "static/chunks/10cbf02e6fc36465.js",
    "static/chunks/turbopack-808cd05d461261d2.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];