1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/10e6b5525379340a.js"],"default"]
3:I[53536,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/10e6b5525379340a.js"],"default"]
0:{"buildId":"08acSMkx2TMLY6sg06Qqc","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
