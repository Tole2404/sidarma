1:"$Sreact.fragment"
2:I[14243,["/_next/static/chunks/575cd9efbdba1453.js","/_next/static/chunks/bde1bed2ffe654b8.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/10e6b5525379340a.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"08acSMkx2TMLY6sg06Qqc","rsc":["$","$1","c",{"children":[["$","$L2",null,{"data":{}}],[["$","script","script-0",{"src":"/_next/static/chunks/575cd9efbdba1453.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/bde1bed2ffe654b8.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
