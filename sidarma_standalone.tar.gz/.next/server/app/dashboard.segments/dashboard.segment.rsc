1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/10e6b5525379340a.js"],"ClientSegmentRoot"]
3:I[39126,["/_next/static/chunks/1e1689b00afc7efa.js","/_next/static/chunks/bde1bed2ffe654b8.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/10e6b5525379340a.js"],"default"]
5:I[53536,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/10e6b5525379340a.js"],"default"]
0:{"buildId":"08acSMkx2TMLY6sg06Qqc","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/1e1689b00afc7efa.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/bde1bed2ffe654b8.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
